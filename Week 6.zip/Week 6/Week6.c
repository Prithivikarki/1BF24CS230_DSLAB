#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct Node{
    int data;
    struct Node *next;
};

struct Node *head = NULL;

struct Node *createNode(int data){
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

void createList(int n){
    if (n <= 0) {
        printf("Enter a valid number\n");
        return;
    }

    struct Node *newNode, *temp = NULL;
    int data;

    for (int i = 0; i < n; i++) {
        printf("Enter data for node:\n");
        scanf("%d", &data);

        newNode = createNode(data);

        if (head == NULL) {
            head = newNode;
            temp = head;
        } else {
            temp->next = newNode;
            temp = newNode;
        }
    }

    printf("Linked list is created\n");
}

void deleteFirstEle() {
    if (head == NULL) {
        printf("LL is empty\n");
        return;
    }

    struct Node *temp = head;
    head = head->next;
    printf("%d was deleted \n", temp->data);
    free(temp);
}

void lastEle() {
    if (head == NULL) {
        printf("LL is empty\n");
        return;
    }

    struct Node *temp = head, *prev = NULL;

    if (head->next == NULL) {
        printf("Deleted Ele is %d\n", head->data);
        free(head);
        head = NULL;
        return;
    }

    while (temp->next != NULL) {
        prev = temp;
        temp = temp->next;
    }

    printf("Deleted Ele is %d\n", temp->data);
    prev->next = NULL;
    free(temp);
}

void deleteSpecificEle(int val) {
    struct Node *temp = head, *prev = NULL;

    if (head == NULL) {
        printf("LL is empty\n");
        return;
    }

    if (head->data == val) {
        temp = head;
        head = head->next;
        printf("Deleted ele %d\n", temp->data);
        free(temp);
        return;
    }

    while (temp != NULL && temp->data != val) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Element not found\n");
        return;
    }

    prev->next = temp->next;
    printf("Deleted ele %d\n", temp->data);
    free(temp);
}

void display() {
    if (head == NULL) {
        printf("Linked list is empty\n");
        return;
    }

    struct Node *temp = head;
    printf("Linked List: ");
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    int choice, n, val;
    bool exit = false;

    printf("--- MENU ---\n");
    printf("1. Create List\n2. Delete First Ele\n3. Delete Last Ele\n4. Delete value\n5. Display\n6. Exit\n");

    while (!exit) {
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the number of nodes: ");
                scanf("%d", &n);
                createList(n);
                break;
            case 2:
                deleteFirstEle();
                break;
            case 3:
                lastEle();
                break;
            case 4:
                printf("Enter data to remove: ");
                scanf("%d", &val);
                deleteSpecificEle(val);
                break;
            case 5:
                display();
                break;
            case 6:
                exit = true;
                break;
            default:
                printf("Enter valid choice\n");
                break;
        }
    }
    return 0;
}

