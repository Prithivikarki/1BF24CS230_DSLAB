#include<stdio.h>
#define MAX 3

int stack[MAX];
int top = -1;

void push(){
    int x;
    printf("Enter the data:");
    scanf("%d",&x);
     if(top==MAX-1){
        printf("Stack overflow\n");
     }
     else{
        top++;
        stack[top] = x;
     }
}

void pop(){
    int value;
    if(top == -1){
        printf("Stack is empty\n");
    }else{
        value = stack[top];
        top --;
        printf("The popped element is %d \n", value);
    }
}

void peek(){
    if(top == -1){
        printf("Empty Stack\n");
    }else{
        printf("Peek value: %d\n",stack[top]);
    }
}
void display(){
    int i;
    if(top == -1){
        printf("Empty Stack\n");
    }else{
        printf("Stack elements: ");
        for(i=top;i>=0;i--){
            printf("%d",stack[i]);
        }
        printf("\n");
    }
}

void main(){
    int choice;
    do{
        printf("Enter choice: \n 1.Push \n 2.Pop\n 3.Peek\n 4.Display\n");
        scanf("%d",&choice);
        switch(choice){
        case 1:
            push();
            break;
        case 2:
            pop();
            break;
        case 3:
            peek();
            break;
        case 4:
            display();
            break;
        case 0:
            printf("Exiting Program \n");
            break;
        }
    }while (choice !=0);
}
