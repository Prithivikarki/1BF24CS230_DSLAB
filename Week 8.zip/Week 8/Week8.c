#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *prev, *next;
};
struct Node *head = NULL;
struct Node* createNode(int data)
{
    struct Node* newNode = (struct Node*) malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->prev = newNode->next = NULL;
    return newNode;
}
void createList(int data)
{
    struct Node* newNode = createNode(data);

    if (head == NULL) {
        head = newNode;
        return;
    }
    struct Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newNode;
    newNode->prev = temp;
}

void insertLeft(int value, int newData)
{
    struct Node* temp = head;

    while (temp != NULL && temp->data != value)
        temp = temp->next;

    if (temp == NULL)
        {
        printf("Node with value %d not found!\n", value);
        return;
    }
    struct Node* newNode = createNode(newData);
    newNode->next = temp;
    newNode->prev = temp->prev;

    if (temp->prev != NULL)
        temp->prev->next = newNode;
    else
        head = newNode;
    temp->prev = newNode;
    printf("Inserted %d to LEFT of %d\n", newData, value);
}

void insertRight(int value, int newData)
 {
    struct Node* temp = head;
    while (temp != NULL && temp->data != value)
        temp = temp->next;
    if (temp == NULL){
        printf("Node with value %d not found!\n", value);
        return;
    }
    struct Node* newNode = createNode(newData);
    newNode->prev = temp;
    newNode->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;

    printf("Inserted %d to RIGHT of %d\n", newData, value);
}

void deleteByValue(int value)
 {
    struct Node* temp = head;

    while (temp != NULL && temp->data != value)
        temp = temp->next;

    if (temp == NULL) {
        printf("Node with value %d not found!\n", value);
        return;
    }

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    free(temp);
    printf("Node with value %d deleted.\n", value);
}

void display() {
    struct Node* temp = head;
    if (temp == NULL) {
        printf("List is empty.\n");
        return;
    }
    printf("Doubly Linked List: ");
    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}
void deleteAtPosition(int position) {
    if (head == NULL || position <= 0) {
        printf("Invalid position.\n");
        return;
    }

    struct Node* temp = head;

    for (int i = 1; temp != NULL && i < position; i++)
        temp = temp->next;

    if (temp == NULL) {
        printf("Position out of range.\n");
        return;
    }

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    printf("Node at position %d deleted.\n", position);
    free(temp);
}

int main() {
    int choice, data, value, pos;
        printf("\n==== DOUBLY LINKED LIST MENU ====\n");
        printf("1. Create List (Insert at end)\n");
        printf("2. Insert Left of a Node\n");
        printf("3. Insert Right of a Node\n");
        printf("4. Delete by Value\n");
        printf("5. Delete at Position\n");
        printf("6. Display\n");
        printf("7. Exit\n");

    while (1) {
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data: ");
                scanf("%d", &data);
                createList(data);
                break;

            case 2:
                printf("Enter existing node value: ");
                scanf("%d", &value);
                printf("Enter data to insert: ");
                scanf("%d", &data);
                insertLeft(value, data);
                break;

            case 3:
                printf("Enter existing node value: ");
                scanf("%d", &value);
                printf("Enter data to insert: ");
                scanf("%d", &data);
                insertRight(value, data);
                break;

            case 4:
                printf("Enter value to delete: ");
                scanf("%d", &value);
                deleteByValue(value);
                break;

            case 5:
                printf("Enter position to delete: ");
                scanf("%d", &pos);
                deleteAtPosition(pos);
                break;

            case 6:
                display();
                break;

            case 7:
                exit(0);

            default:
                printf("Invalid choice!\n");
        }
    }
}
