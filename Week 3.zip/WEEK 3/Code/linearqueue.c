#include<stdio.h>
#include <stdbool.h>
#define m 1
int front = - 1;
int rear = -1;
int queue[m];

void enque(int x){
    if(rear == m-1){
        printf("Queue is full\n");
    }else if(front==-1 && rear ==-1){
        front=rear=0;
        queue[rear] = x;
    }else {
        rear++;
        queue[rear] = x;
    }
}

int deque(){
    if(front == - 1 && rear ==-1){
        printf("Queue is empty\n");
    }else if(front==0 && rear ==0){
        int ele = queue[front];
        front=rear=-1;
        return ele;
    }else {
        int ele = queue[front];
        front++ ;
        return ele;
    }
}

void display(){
 int i;
 printf("Elements are:-\n");
 for(i=front;i<=rear;i++){
    printf("%d\n",queue[i]);
 }
}

int main(){
int choice;
int x;
bool exit = false;
do{
    printf("Enter choice:\n");
printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n");
scanf("%d",&choice);
switch(choice){
case 1:
    printf("Enter num to input\n");
    scanf("%d",&x);
    enque(x);
    break;
case 2:
    deque();
    break;
case 3:
    display();
    break;
case 4:
    exit = true;
    break;
default:
    printf("Enter valid input");
    break;

}
}while(exit == false);
}
