#include<stdio.h>
#include <stdbool.h>
#define m 5
int front = - 1;
int rear = -1;
int queue[m];

void enque(int x){
    if((rear+1)%m == front){
        printf("Queue is full\n");
    }else if(front==-1 && rear ==-1){
        front=rear=0;
        queue[rear] = x;
    }else {
        rear=(rear+1)%m;
        queue[rear] = x;
    }
}

int deque(){
    if(front == - 1 && rear ==-1){
        printf("Queue is empty\n");
    }else if(front==0 && rear ==0){
        int ele = queue[front];
        front=rear=-1;
        return ele;
    }else {
        int ele = queue[front];
        front = (front+1)%m;
        return ele;
    }
}

void display(){

 if(front==-1 && rear ==-1){
        printf("Queue is empty");
    }
else{
        int i=front;
     printf("Elements are:-\n");
     while(1){
        printf("%d\n",queue[i]);
        if(i==rear){
            break;
        }
        i = (i+1)%m;
     }
}
}

int main(){
int choice;
int x;
bool exit = false;
do{
    printf("Enter choice:\n");
printf("1.Insert\n2.Delete\n3.Display\n4.Exit\n");
scanf("%d",&choice);
switch(choice){
case 1:
    printf("Enter num to input\n");
    scanf("%d",&x);
    enque(x);
    break;
case 2:
    deque();
    break;
case 3:
    display();
    break;
case 4:
    exit = true;
    break;
default:
    printf("Enter valid input");
    break;

}
}while(exit == false);
}
